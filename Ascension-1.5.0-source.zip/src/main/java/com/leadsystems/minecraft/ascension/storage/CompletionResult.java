package com.leadsystems.minecraft.ascension.storage;

/** Outcome of the quest-completion transaction. */
public enum CompletionResult { ADVANCED, MASTERED, ALREADY_DONE, NOT_ACTIVE, RANK_MISMATCH }
