# Ascension banner

Copyright (c) 2026 Ayush Anand. Distributed under the project's personal-use license.
Created with the built-in image-generation tool for this project.

Prompt: Original voxel fantasy GitHub banner for Ascension: an enchanted chronicle,
winged adventurer, lightning, emerald-block market stall, and rising rank emblem.
Only text: ASCENSION. No Minecraft/Mojang logos or copyrighted characters. Emerald,
gold and storm-blue lighting over charcoal stone. In-game text remains neutral.
