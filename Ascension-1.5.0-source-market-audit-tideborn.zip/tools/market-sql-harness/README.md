# Market SQL harness

`bash tools/market-sql-harness/run.sh` runs 86 checks on the real market storage code and the real SQLite
schema (migrations V11 and V12), with no Paper server and no mocks:

- shop purchases, price rises, restocks, price floor and cap, sold-out and last-bundle races
- the 1.5.0 to catalog v3 migration on a database that is in use, including an in-flight purchase of a removed product
- all three currency exchange routes, double commits and aborts
- auction listing, buying, cancelling, claiming, partial claims, the 10-listing limit, paging
- catch-up after server downtime (150 overdue products)

It does not cover the Bukkit layer (menus, commands, inventories, Bedrock forms). Those need `gradle test`
or a real server.
