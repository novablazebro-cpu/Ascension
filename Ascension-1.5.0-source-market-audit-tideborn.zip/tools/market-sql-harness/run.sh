#!/usr/bin/env bash
# Runs the real MarketRepository and DynamicShopRepository against a real in-memory SQLite database.
# Needs only a JDK and internet access to Maven Central; it does not need Paper. Run from anywhere.
set -euo pipefail
cd "$(dirname "$0")/../.."
LIB="$(mktemp -d)"
trap 'rm -rf "$LIB"' EXIT
BASE=https://repo1.maven.org/maven2
curl -fsSL -o "$LIB/sqlite.jar"   "$BASE/org/xerial/sqlite-jdbc/3.47.0.0/sqlite-jdbc-3.47.0.0.jar"
curl -fsSL -o "$LIB/slf4j.jar"    "$BASE/org/slf4j/slf4j-api/2.0.13/slf4j-api-2.0.13.jar"
curl -fsSL -o "$LIB/snakeyaml.jar" "$BASE/org/yaml/snakeyaml/2.2/snakeyaml-2.2.jar"
mkdir "$LIB/out"
M=src/main/java/com/leadsystems/minecraft/ascension
javac -d "$LIB/out" -cp "$LIB/snakeyaml.jar" \
  "$M/storage/Tx.java" "$M/storage/SqlTask.java" "$M/market/MarketRepository.java" \
  "$M/market/DynamicShopRepository.java" tools/market-sql-harness/MarketSqlHarness.java
java -cp "$LIB/out:$LIB/sqlite.jar:$LIB/slf4j.jar:$LIB/snakeyaml.jar" MarketSqlHarness src/main/resources \
  2> >(grep -v '^SLF4J' >&2)
