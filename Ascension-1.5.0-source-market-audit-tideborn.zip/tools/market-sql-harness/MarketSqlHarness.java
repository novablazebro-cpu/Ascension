import com.leadsystems.minecraft.ascension.market.DynamicShopRepository;
import com.leadsystems.minecraft.ascension.market.DynamicShopRepository.Offer;
import com.leadsystems.minecraft.ascension.market.DynamicShopRepository.Product;
import com.leadsystems.minecraft.ascension.market.MarketRepository;
import com.leadsystems.minecraft.ascension.market.MarketRepository.Operation;
import org.yaml.snakeyaml.Yaml;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Runs the real repository classes against real SQLite. Prints PASS/FAIL per check; exit 1 on any FAIL. */
public final class MarketSqlHarness {
    static int failures, checks;
    static final byte[] INV = {1, 2, 3};

    static void check(String name, boolean ok) {
        checks++;
        if (!ok) failures++;
        System.out.println((ok ? "PASS " : "FAIL ") + name);
    }

    @SuppressWarnings("unchecked")
    static List<Product> catalog(Path file) throws Exception {
        try (InputStream in = Files.newInputStream(file)) {
            Map<String, Object> root = new Yaml().load(in);
            Map<String, Object> restock = (Map<String, Object>) root.get("restock");
            Map<String, Object> price = (Map<String, Object>) root.get("price");
            List<Product> out = new ArrayList<>();
            ((Map<String, Map<String, Object>>) root.get("products")).forEach((id, p) -> out.add(new Product(id,
                    (String) p.get("material"), (Integer) p.get("quantity"), (String) p.get("label"),
                    (Integer) p.get("base-price"), (Integer) p.get("min-price"), (Integer) p.get("max-price"),
                    (Integer) price.get("purchase-step"), (Integer) price.get("restock-drop"),
                    (Integer) p.get("max-stock"), (Integer) p.get("restock-amount"),
                    (Integer) restock.get("min-seconds"), (Integer) restock.get("max-seconds"))));
            return out;
        }
    }

    static Connection db(Path resources) throws Exception {
        Connection c = DriverManager.getConnection("jdbc:sqlite::memory:");
        for (String v : List.of("V11__market.sql", "V12__dynamic_shop.sql")) {
            String sql = Files.readString(resources.resolve("db/sqlite/" + v));
            try (Statement s = c.createStatement()) {
                for (String part : sql.split(";\\s*\\r?\\n")) if (!part.isBlank()) s.execute(part);
            }
        }
        return c;
    }

    static Operation op(UUID actor, String kind, String ref, String currency, int price, byte[] item, String itemName) {
        return new Operation(UUID.randomUUID().toString(), actor, kind, ref, INV, new byte[] {9, 9}, item, itemName,
                currency, price, "P" + actor.toString().substring(0, 4), 1_000L);
    }

    static Offer find(DynamicShopRepository shop, Connection c, String id) throws Exception { return shop.find(c, id); }

    static boolean buy(MarketRepository market, Connection c, UUID who, Offer o, long now, boolean commit) throws Exception {
        Operation op = new Operation(UUID.randomUUID().toString(), who, "SHOP", o.product().id() + "|" + o.currentPrice(),
                INV, new byte[] {9}, new byte[] {7}, o.product().label(), "EMERALD_BLOCK", o.currentPrice(), "Buyer", now);
        if (!market.prepare(c, op)) return false;
        return commit ? market.commit(c, op.id()) : market.abort(c, op.id());
    }

    public static void main(String[] args) throws Exception {
        Path res = Path.of(args[0]);
        List<Product> v2 = catalog(res.resolve("shop-catalog-v2.yml"));
        List<Product> v3 = catalog(res.resolve("shop.yml"));
        var market = new MarketRepository();
        var shop = new DynamicShopRepository();
        long t0 = 1_000_000L;
        java.util.function.IntBinaryOperator rnd = (lo, hi) -> lo;

        // ---- Shop lifecycle on the v3 catalog -------------------------------------------------
        try (Connection c = db(res)) {
            shop.seed(c, v3, t0, rnd);
            check("v3 seeds 150 enabled products", shop.offers(c).size() == 150);
            Offer chest = find(shop, c, "diamond_chestplate");
            check("diamond chestplate starts at 10 blocks, stock 4", chest.currentPrice() == 10 && chest.stock() == 4);
            UUID a = UUID.randomUUID(), b = UUID.randomUUID();
            check("purchase 1 commits", buy(market, c, a, find(shop, c, "diamond_chestplate"), t0, true));
            Offer after = find(shop, c, "diamond_chestplate");
            check("price rises 10 -> 11, stock 4 -> 3, not reserved", after.currentPrice() == 11 && after.stock() == 3 && !after.reserved());
            for (int i = 0; i < 5; i++) buy(market, c, a, find(shop, c, "diamond_chestplate"), t0, true);
            Offer capped = find(shop, c, "diamond_chestplate");
            check("price is capped at 20 (double the start) and stock never negative", capped.currentPrice() <= 20 && capped.stock() == 0);
            check("sold-out product cannot be bought", !buy(market, c, b, capped, t0, true));
            long due = t0 + 7_200_000L + 1;
            check("restock adds stock, lowers price, stays within bounds", shop.restock(c, due, rnd) > 0);
            Offer re = find(shop, c, "diamond_chestplate");
            check("after restock: stock +2, price -1", re.stock() == 2 && re.currentPrice() == capped.currentPrice() - 1);
            for (int i = 0; i < 40; i++) shop.restock(c, due + i * 8_000_000L, rnd);
            check("price falls back to the floor (10), never below", find(shop, c, "diamond_chestplate").currentPrice() == 10);
            check("stock refills to max 4 only", find(shop, c, "diamond_chestplate").stock() == 4);

            // two buyers, one bundle
            Offer last = find(shop, c, "diamond_sword");
            for (int i = 0; i < 3; i++) buy(market, c, a, find(shop, c, "diamond_sword"), due, true);
            Offer one = find(shop, c, "diamond_sword");
            Operation first = new Operation(UUID.randomUUID().toString(), a, "SHOP", one.product().id() + "|" + one.currentPrice(), INV, INV, new byte[] {1}, "x", "EMERALD_BLOCK", one.currentPrice(), "A", due);
            Operation second = new Operation(UUID.randomUUID().toString(), b, "SHOP", one.product().id() + "|" + one.currentPrice(), INV, INV, new byte[] {1}, "x", "EMERALD_BLOCK", one.currentPrice(), "B", due);
            check("last bundle: first reservation wins", market.prepare(c, first));
            check("last bundle: second buyer refused (no oversell)", !market.prepare(c, second));
            check("abort releases the reservation and returns the bundle", market.abort(c, first.id()) && find(shop, c, "diamond_sword").stock() == one.stock());
            check("abort does not raise the price", find(shop, c, "diamond_sword").currentPrice() == one.currentPrice());
            check("committing twice creates exactly one delivery", twice(market, c, b));
            Statement s = c.createStatement();
            var rs = s.executeQuery("SELECT COUNT(*) FROM market_deliveries WHERE id LIKE '%:shop'");
            rs.next();
            check("shop deliveries exist for each committed purchase", rs.getInt(1) > 5);
        }

        // ---- Migration 1.5.0 (v2) -> v3 against an in-use database ----------------------------
        try (Connection c = db(res)) {
            shop.seed(c, v2, t0, rnd);
            UUID a = UUID.randomUUID();
            for (int i = 0; i < 3; i++) buy(market, c, a, find(shop, c, "diamond_chestplate"), t0, true);
            Offer worn = find(shop, c, "diamond_chestplate");
            check("v2 chestplate was bought up to " + worn.currentPrice(), worn.currentPrice() == 8);
            // an elytra purchase is mid-flight when the server is updated
            Offer elytra = find(shop, c, "elytra");
            Operation pending = new Operation(UUID.randomUUID().toString(), a, "SHOP", "elytra|" + elytra.currentPrice(), INV, INV, new byte[] {5}, "1 x Elytra", "EMERALD_BLOCK", elytra.currentPrice(), "A", t0);
            check("elytra purchase prepared before the update", market.prepare(c, pending));
            shop.seed(c, v3, t0 + 1000, rnd);
            check("after update elytra, totem, trident, diamond are gone from the menu",
                    shop.find(c, "elytra") == null && shop.find(c, "totem_of_undying") == null
                            && shop.find(c, "trident") == null && shop.find(c, "diamond") == null);
            check("new v3 products are present", shop.find(c, "spectral_arrow") != null && shop.find(c, "firework_rocket") != null
                    && shop.find(c, "chainmail_chestplate") != null && shop.find(c, "flint") != null);
            check("menu has exactly 150 products", shop.offers(c).size() == 150);
            Offer clamped = find(shop, c, "diamond_chestplate");
            check("chestplate price clamped into the v3 bounds [10,20] (was 8)", clamped.currentPrice() == 10);
            check("stock clamped to the new max 4", clamped.stock() <= 4);
            check("in-flight elytra purchase still commits and delivers after removal", market.commit(c, pending.id()));
            var rs = c.createStatement().executeQuery("SELECT COUNT(*) FROM market_deliveries WHERE id='" + pending.id() + ":shop'");
            rs.next();
            check("the buyer receives the elytra they paid for", rs.getInt(1) == 1);
            // a worn-down price above the new cap must clamp down, not violate CHECK
            c.createStatement().execute("UPDATE dynamic_shop_products SET current_price=3, stock=4 WHERE id='iron_sword'");
            shop.seed(c, v3, t0 + 2000, rnd);
            check("re-seeding an unchanged catalog is idempotent", shop.offers(c).size() == 150);
        }

        // ---- Currency exchange (journal rows) --------------------------------------------------
        try (Connection c = db(res)) {
            UUID a = UUID.randomUUID();
            String[][] routes = {{"netherite_to_diamond", "NETHERITE_INGOT", "1"}, {"diamond_to_emerald", "DIAMOND_BLOCK", "1"}, {"netherite_to_emerald", "NETHERITE_INGOT", "1"}};
            for (String[] r : routes) {
                Operation o = op(a, "EXCHANGE", r[0], r[1], Integer.parseInt(r[2]), new byte[] {4}, "4 Diamond Blocks");
                check(r[0] + " prepares", market.prepare(c, o));
                check(r[0] + " second operation refused while one is pending", !market.prepare(c, op(a, "EXCHANGE", r[0], r[1], 1, new byte[] {4}, "x")));
                check(r[0] + " commits", market.commit(c, o.id()));
                check(r[0] + " recommit is harmless", market.commit(c, o.id()));
                var rs = c.createStatement().executeQuery("SELECT COUNT(*) FROM market_deliveries WHERE id='" + o.id() + ":exchange'");
                rs.next();
                check(r[0] + " creates exactly one delivery", rs.getInt(1) == 1);
            }
            Operation bad = op(a, "EXCHANGE", "x", "EMERALD_BLOCK", 0, new byte[] {1}, "x");
            check("zero-price exchange refused", !market.prepare(c, bad));
            Operation badCurrency = op(a, "EXCHANGE", "x", "GOLD_BLOCK", 4, new byte[] {1}, "x");
            check("non-currency exchange refused", !market.prepare(c, badCurrency));
            Operation abort = op(a, "EXCHANGE", "diamond_to_emerald", "DIAMOND_BLOCK", 1, new byte[] {4}, "4 Emerald Blocks");
            market.prepare(c, abort);
            check("aborted exchange makes no delivery", market.abort(c, abort.id()) && !market.commit(c, abort.id()));
        }

        // ---- Auction: sell / buy / cancel / claim ----------------------------------------------
        try (Connection c = db(res)) {
            UUID seller = UUID.randomUUID(), buyer = UUID.randomUUID();
            List<String> ids = new ArrayList<>();
            for (int i = 0; i < 10; i++) {
                String listing = UUID.randomUUID().toString();
                Operation sell = op(seller, "SELL", listing, "EMERALD_BLOCK", 5, new byte[] {8}, "1 x Thing");
                check("listing " + (i + 1) + " accepted", market.prepare(c, sell) && market.commit(c, sell.id()));
                ids.add(listing);
            }
            check("11th listing refused (limit 10)", !market.prepare(c, op(seller, "SELL", UUID.randomUUID().toString(), "EMERALD_BLOCK", 5, new byte[] {8}, "x")));
            check("seller cannot buy their own listing", !market.prepare(c, op(seller, "BUY", ids.get(0), "EMERALD_BLOCK", 5, new byte[] {2}, "x")));
            check("wrong price refused", !market.prepare(c, op(buyer, "BUY", ids.get(0), "EMERALD_BLOCK", 4, new byte[] {2}, "x")));
            check("wrong currency refused", !market.prepare(c, op(buyer, "BUY", ids.get(0), "DIAMOND_BLOCK", 5, new byte[] {2}, "x")));
            Operation buy = op(buyer, "BUY", ids.get(0), "EMERALD_BLOCK", 5, new byte[] {2}, "1 x Thing");
            check("buyer reserves listing", market.prepare(c, buy));
            check("another buyer cannot take a reserved listing", !market.prepare(c, op(UUID.randomUUID(), "BUY", ids.get(0), "EMERALD_BLOCK", 5, new byte[] {2}, "x")));
            check("seller cannot cancel a reserved listing", !market.prepare(c, op(seller, "CANCEL", ids.get(0), null, 0, null, "x")));
            check("buy commits", market.commit(c, buy.id()));
            var rs = c.createStatement().executeQuery("SELECT owner_uuid FROM market_deliveries ORDER BY owner_uuid");
            List<String> owners = new ArrayList<>(); while (rs.next()) owners.add(rs.getString(1));
            check("buyer gets the item and seller gets the payment", owners.contains(buyer.toString()) && owners.contains(seller.toString()) && owners.size() == 2);
            check("sold listing cannot be bought again", !market.prepare(c, op(UUID.randomUUID(), "BUY", ids.get(0), "EMERALD_BLOCK", 5, new byte[] {2}, "x")));
            Operation cancel = op(seller, "CANCEL", ids.get(1), null, 0, null, "Cancelled listing");
            check("seller cancels own listing", market.prepare(c, cancel) && market.commit(c, cancel.id()));
            check("stranger cannot cancel someone else's listing", !market.prepare(c, op(buyer, "CANCEL", ids.get(2), null, 0, null, "x")));
            var d = market.deliveries(c, buyer, 0, 10);
            check("buyer sees one delivery", d.size() == 1);
            Operation claim = op(buyer, "CLAIM", d.get(0).id(), null, 0, null, "claim");
            check("claim prepares (reserved)", market.prepare(c, claim));
            check("reserved delivery is hidden from list", market.deliveries(c, buyer, 0, 10).isEmpty());
            check("stranger cannot claim it", !market.prepare(c, op(seller, "CLAIM", d.get(0).id(), null, 0, null, "x")));
            check("claim commits and the delivery is gone", market.commit(c, claim.id()) && market.deliveries(c, buyer, 0, 10).isEmpty());
            // partial claim keeps a remainder
            var sd = market.deliveries(c, seller, 0, 10);
            Operation partial = op(seller, "CLAIM", sd.get(0).id(), null, 0, new byte[] {3}, "partial");
            check("seller has two deliveries before claiming (payment + returned listing)", sd.size() == 2);
            String claimed = sd.get(0).id();
            check("partial claim prepares and commits", market.prepare(c, partial) && market.commit(c, partial.id()));
            var after = market.deliveries(c, seller, 0, 10);
            check("partial claim keeps the delivery available with the remainder bytes",
                    after.size() == 2 && after.stream().anyMatch(x -> x.id().equals(claimed) && java.util.Arrays.equals(x.item(), new byte[] {3})));
            // abort path restores a listing
            Operation buy2 = op(buyer, "BUY", ids.get(3), "EMERALD_BLOCK", 5, new byte[] {2}, "x");
            market.prepare(c, buy2);
            check("aborted buy returns the listing to the market", market.abort(c, buy2.id()) && market.listing(c, ids.get(3)) != null);
            check("pending list empty after everything resolved", market.pending(c).isEmpty());
        }

        // ---- Paging and downtime catch-up ------------------------------------------------------
        try (Connection c = db(res)) {
            List<UUID> sellers = List.of(UUID.randomUUID(), UUID.randomUUID(), UUID.randomUUID());
            long at = 10_000;
            for (UUID who : sellers) for (int i = 0; i < 10; i++) {
                Operation sell = new Operation(UUID.randomUUID().toString(), who, "SELL", UUID.randomUUID().toString(), INV, INV,
                        new byte[] {8}, "item", "EMERALD_BLOCK", 3, "S", at++);
                market.prepare(c, sell); market.commit(c, sell.id());
            }
            check("browse page 0 returns 11 rows (10 + 1 lookahead)", market.listings(c, null, 0, 11).size() == 11);
            check("browse page 2 returns the last 10", market.listings(c, null, 20, 11).size() == 10);
            check("browse page 3 is empty", market.listings(c, null, 30, 11).isEmpty());
            check("my listings shows only the owner's 10", market.listings(c, sellers.get(1), 0, 11).size() == 10);
            check("newest listing first", market.listings(c, null, 0, 11).get(0).createdAt() > market.listings(c, null, 0, 11).get(10).createdAt());
            check("negative offset is rejected safely", market.listings(c, null, -1, 11).isEmpty());
        }
        try (Connection c = db(res)) {
            shop.seed(c, v3, t0, rnd);
            long later = t0 + 3L * 24 * 3600 * 1000; // server was offline for three days
            int total = 0, rounds = 0, changed;
            while ((changed = shop.restock(c, later, rnd)) > 0 && rounds < 10) { total += changed; rounds++; }
            check("all 150 overdue products restock exactly once after downtime", total == 150);
            check("catch-up takes ceil(150/64)=3 scheduler ticks", rounds == 3);
            var rs = c.createStatement().executeQuery("SELECT COUNT(*) FROM dynamic_shop_products WHERE next_restock<=" + later);
            rs.next();
            check("nothing is still overdue afterwards", rs.getInt(1) == 0);
            check("restocking never exceeds max stock or breaks price bounds", shop.offers(c).stream().allMatch(o ->
                    o.stock() <= o.product().maxStock() && o.currentPrice() >= o.product().minPrice() && o.currentPrice() <= o.product().maxPrice()));
        }

        System.out.println("\n" + (checks - failures) + "/" + checks + " checks passed");
        System.exit(failures == 0 ? 0 : 1);
    }

    static boolean twice(MarketRepository market, Connection c, UUID who) throws Exception {
        var shop = new DynamicShopRepository();
        Offer o = shop.find(c, "iron_sword");
        Operation op = new Operation(UUID.randomUUID().toString(), who, "SHOP", "iron_sword|" + o.currentPrice(), INV, INV, new byte[] {1}, "x", "EMERALD_BLOCK", o.currentPrice(), "B", 5_000_000L);
        if (!market.prepare(c, op)) return false;
        boolean first = market.commit(c, op.id());
        boolean again = market.commit(c, op.id());
        var rs = c.createStatement().executeQuery("SELECT COUNT(*) FROM market_deliveries WHERE id='" + op.id() + ":shop'");
        rs.next();
        return first && again && rs.getInt(1) == 1;
    }
}
