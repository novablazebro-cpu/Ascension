package com.leadsystems.minecraft.ascension.cosmetic;

import com.leadsystems.minecraft.ascension.api.event.RankAdvancedEvent;
import com.leadsystems.minecraft.ascension.config.ConfigSnapshot;
import com.leadsystems.minecraft.ascension.domain.rank.RankStage;
import com.leadsystems.minecraft.ascension.domain.title.TitleDefinition;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.title.Title;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;

import java.time.Duration;
import java.util.function.Supplier;
import java.util.logging.Level;

/**
 * Short visual celebrations for title equips, title level-ups and rank advances: an on-screen title
 * plus a particle animation in the title's or rank's own colour. Each animation is one task that
 * cancels itself after at most two seconds or when the player leaves, so nothing outlives the moment.
 * Cosmetics never break gameplay: a failure is logged and the animation is dropped.
 */
public final class Celebrations implements Listener {

    private static final Color FALLBACK = Color.fromRGB(0xF5D76E);
    private static final Title.Times TIMES = Title.Times.times(
            Duration.ofMillis(250), Duration.ofMillis(1800), Duration.ofMillis(600));

    private final Plugin plugin;
    private final Supplier<ConfigSnapshot> config;

    public Celebrations(Plugin plugin, Supplier<ConfigSnapshot> config) {
        this.plugin = plugin;
        this.config = config;
    }

    /** A rising double helix in the title's colour, then a burst at head height. */
    public void titleEquipped(Player player, TitleDefinition title) {
        safely(() -> {
            Color color = color(title.color());
            player.showTitle(Title.title(
                    Component.text(title.name(), textColor(title.color())).decorate(TextDecoration.BOLD),
                    Component.text(title.abilityName(), NamedTextColor.GRAY), TIMES));
            player.playSound(player.getLocation(), Sound.BLOCK_BEACON_POWER_SELECT, 0.7f, 1.4f);
            animate(player, 30, (world, base, tick) -> {
                double progress = tick / 30.0;
                double y = progress * 2.2;
                double radius = 0.9 - progress * 0.35;
                for (int strand = 0; strand < 2; strand++) {
                    double angle = tick * 0.42 + strand * Math.PI;
                    world.spawnParticle(Particle.DUST, base.clone().add(Math.cos(angle) * radius, y,
                            Math.sin(angle) * radius), 1, 0, 0, 0, 0, new Particle.DustOptions(color, 1.2f));
                }
                if (tick == 29) {
                    world.spawnParticle(Particle.END_ROD, base.clone().add(0, 2.2, 0), 24, 0.25, 0.25, 0.25, 0.08);
                    player.playSound(player.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1f, 1.2f);
                }
            });
        });
    }

    /** Two expanding rings in the title's colour, a totem burst and a level banner. */
    public void titleLevelUp(Player player, String titleId, int level) {
        safely(() -> {
            TitleDefinition title = config.get().titles().byId(titleId);
            if (title == null) return;
            Color color = color(title.color());
            player.showTitle(Title.title(
                    Component.text(title.name() + " Lv." + level, textColor(title.color())).decorate(TextDecoration.BOLD),
                    Component.text(title.abilityName() + " grows stronger", NamedTextColor.GRAY), TIMES));
            player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 0.8f);
            player.playSound(player.getLocation(), Sound.ITEM_TOTEM_USE, 0.4f, 1.6f);
            animate(player, 24, (world, base, tick) -> {
                if (tick == 0) {
                    world.spawnParticle(Particle.TOTEM_OF_UNDYING, base.clone().add(0, 1.1, 0), 40, 0.3, 0.6, 0.3, 0.35);
                }
                ring(world, base.clone().add(0, 0.15, 0), 0.4 + tick * 0.11, color);
                if (tick >= 8) ring(world, base.clone().add(0, 0.15, 0), 0.4 + (tick - 8) * 0.11, Color.WHITE);
            });
        });
    }

    /** Fireworks-style sparks and a rank banner; QuestService already plays the sound and chat line. */
    @EventHandler(priority = EventPriority.MONITOR)
    public void onRankAdvanced(RankAdvancedEvent event) {
        safely(() -> {
            Player player = event.getPlayer();
            ConfigSnapshot snapshot = config.get();
            if (event.getToIndex() < 0 || event.getToIndex() >= snapshot.ladder().size()) return;
            RankStage stage = snapshot.ladder().get(event.getToIndex());
            Color color = color(stage.color());
            Component headline = event.isMastery()
                    ? Component.text(snapshot.masteryName(), NamedTextColor.GOLD).decorate(TextDecoration.BOLD)
                    : Component.text(stage.name(), textColor(stage.color())).decorate(TextDecoration.BOLD);
            player.showTitle(Title.title(headline,
                    Component.text(event.isMastery() ? "Mastery achieved" : "Rank advanced", NamedTextColor.GRAY), TIMES));
            animate(player, 36, (world, base, tick) -> {
                if (tick % 6 != 0) return;
                double angle = tick * 0.9;
                Location burst = base.clone().add(Math.cos(angle) * 1.2, 2.4 + (tick % 12) * 0.05, Math.sin(angle) * 1.2);
                world.spawnParticle(Particle.FIREWORK, burst, 18, 0.05, 0.05, 0.05, 0.12);
                world.spawnParticle(Particle.DUST, burst, 10, 0.3, 0.3, 0.3, 0,
                        new Particle.DustOptions(color, 1.4f));
                player.playSound(player.getLocation(), Sound.ENTITY_FIREWORK_ROCKET_BLAST, 0.6f, 1f + tick / 72f);
            });
        });
    }

    private interface Frame { void draw(World world, Location base, int tick); }

    /** Runs one frame per tick, following the player, for {@code ticks} ticks. */
    private void animate(Player player, int ticks, Frame frame) {
        if (!plugin.isEnabled()) return;
        new BukkitRunnable() {
            private int tick;

            @Override
            public void run() {
                if (tick >= ticks || !player.isOnline()) {
                    cancel();
                    return;
                }
                try {
                    frame.draw(player.getWorld(), player.getLocation(), tick++);
                } catch (RuntimeException e) {
                    cancel();
                    plugin.getLogger().log(Level.FINE, "Celebration animation stopped", e);
                }
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    private static void ring(World world, Location centre, double radius, Color color) {
        Particle.DustOptions dust = new Particle.DustOptions(color, 1f);
        int points = 14 + (int) (radius * 8);
        for (int i = 0; i < points; i++) {
            double angle = 2 * Math.PI * i / points;
            world.spawnParticle(Particle.DUST, centre.clone().add(Math.cos(angle) * radius, 0, Math.sin(angle) * radius),
                    1, 0, 0, 0, 0, dust);
        }
    }

    private void safely(Runnable action) {
        try {
            action.run();
        } catch (RuntimeException e) {
            plugin.getLogger().log(Level.FINE, "Celebration skipped", e);
        }
    }

    private static TextColor textColor(String hex) {
        TextColor parsed = hex == null ? null : TextColor.fromHexString(hex);
        return parsed == null ? NamedTextColor.GOLD : parsed;
    }

    private static Color color(String hex) {
        TextColor parsed = hex == null ? null : TextColor.fromHexString(hex);
        return parsed == null ? FALLBACK : Color.fromRGB(parsed.value());
    }
}
